import { ReactSVG } from 'react-svg';

function GalleryMap() {
  return (
    <ReactSVG
      src="/galeriaparter.svg"
      afterInjection={(error, svg) => {
        if (error) {
          console.error(error);
          return;
        }

        const room = svg.getElementById('room1');
        if (room) {
          room.addEventListener('click', () => alert('Kliknięto room1'));
          room.style.cursor = 'pointer';
          room.style.fill = '#ffa500'; // zmiana koloru
        }
      }}
    />
  );
}

export default GalleryMap;